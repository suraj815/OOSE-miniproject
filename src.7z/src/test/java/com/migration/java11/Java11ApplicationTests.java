package com.migration.java11;

import com.migration.java11.controller.EmployeeController;
import com.migration.java11.repository.EmployeeRepository;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
class Java11ApplicationTests {

    @Mock
    private EmployeeRepository employeeRepository;

    @Autowired
    private EmployeeController employeeController;

	@Test
	void contextLoads() {
        System.out.println("Inside context Loads");
        Assert.assertNotNull("Hello");
	}

    @Test
    public void testSomething(){
       // LOGGER.info("Inside Test Employee Controller");
        employeeController.getEmployee();
        // asser
        Assert.assertNotNull(employeeController);
    }

}
