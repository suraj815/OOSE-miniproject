package com.migration.java11.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.migration.java11.services.EmployeeService;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeControllerTest {

    @InjectMocks
    EmployeeController employeeController;

    @Mock
    EmployeeService employeeService;

   /* @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }*/
    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeControllerTest.class);
    
    
    @Test
    public void testSomething(){
        LOGGER.info("Inside Test Employee Controller");
        employeeController.getEmployee();
        // asser
        Assert.assertNotNull(employeeController);
    }
}
