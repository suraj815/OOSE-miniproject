package com.migration.java11.learning;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetDemo {

    public static void main(String[] args) {
        try {
            Set<String> set = new LinkedHashSet<>();
            System.out.println(set.add(null));
            System.out.println(set.add(null));
            
            System.out.println(set.size());
        } catch (Exception e) {
            // TODO: handle exception
        }
    }
}
