package com.migration.java11.learning;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class Learning {

    public static void main(String[] args) {
        try {
            Queue<String> queue = new PriorityQueue<>();
            queue.add("c");
            queue.add("z");
            queue.add("a");

            System.out.println("c".compareTo("z"));
            System.out.println("a".compareTo("z"));
            System.out.println("a".compareTo("c"));

            // queue.forEach(System.out::println);
            Deque<String> deque = new ArrayDeque<>();
            deque.add("A");
            deque.add("C");
            deque.add("F");
            deque.add(null);
            Iterator it = deque.iterator();
            while (it.hasNext()) {
                System.out.println(it.next());
            }

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }
}
