package com.migration.java11.learning;

import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayListDemo {

    public static void main(String[] args) {
        try {
            // LinkedList
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }
}
