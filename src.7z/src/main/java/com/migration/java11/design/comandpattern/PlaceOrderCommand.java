package com.migration.java11.design.comandpattern;

public class PlaceOrderCommand implements Command {

    Order order;

    public PlaceOrderCommand(Order order) {
        this.order = order;
    }

    @Override
    public void execute() {
        this.order.placeOrder();
    }

}
