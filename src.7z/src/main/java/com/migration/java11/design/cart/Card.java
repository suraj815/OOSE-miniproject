package com.migration.java11.design.cart;

class Card extends Product {
    public Card(String name, double price) {
        this.name = name;
        this.price = price;
    }
}