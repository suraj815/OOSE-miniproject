package com.migration.java11.design.comandpattern;

public class RobotInvoker {

    private Command command;

    public void setCommand(Command command) {
        this.command = command;
    }

    public void initiate(){
        command.execute();
    }
    
}
