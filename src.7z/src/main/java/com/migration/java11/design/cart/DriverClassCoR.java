package com.migration.java11.design.cart;

public class DriverClassCoR {
    public static void main(String[] args) {
        Product card1 = new Card("Card", 12.99);
        Product card2 = new Card("Card", 12.99);
        Product card3 = new Card("Card", 12.99);
        Product tshirt1 = new Tshirt("Tshirt", 24.99);
        Product tshirt2 = new Tshirt("Tshirt", 24.99);
        Product backPack1 = new BackPack("Orange", 34.99);
        ShoppingCart cart = new ShoppingCart();
        cart.addItem(card1);
        cart.addItem(card2);
        cart.addItem(card3);
        Coupon couponAll = new CouponAll();
        cart.addItem(tshirt1);
        Coupon couponNext = new CouponNext(cart.getItems().size());
        couponAll.setSuccessor(couponNext);

        Coupon couponNextBackPack = null;
        couponNextBackPack = new CouponNextProductType(cart.getItems().size(), BackPack.class);
        couponNext.setSuccessor(couponNextBackPack);
        
        cart.addItem(tshirt2);
        cart.addItem(backPack1);
        
        System.out.println("Total cart value before discounts \t" + cart.totalCartValue());
        couponAll.apply(cart);
        // System.out.println(backPack1.getClass().isInstance(backPack1));
        System.out.println("Total cart value after discounts \t" + cart.totalCartValue());
    }
}
