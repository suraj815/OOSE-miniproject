package com.migration.java11.design.cart;

interface Coupon {
    void apply(Cart cart);

    void setSuccessor(Coupon successor);
}
