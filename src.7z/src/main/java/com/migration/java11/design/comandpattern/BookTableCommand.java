package com.migration.java11.design.comandpattern;

public class BookTableCommand implements Command {

    private Table table;

    public BookTableCommand(Table table) {
        this.table = table;
    }

    @Override
    public void execute() {
        table.bookTable();
    }

}
