package com.migration.java11.design.comandpattern;

public class PastaOrder implements Order{

    @Override
    public void placeOrder() {
        System.out.println("Order for Pasta is placed");
    }

    @Override
    public void serveOrder() {
        System.out.println("Pasta is served");
    }

    
}
