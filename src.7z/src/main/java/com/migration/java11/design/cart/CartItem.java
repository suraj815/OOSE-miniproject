package com.migration.java11.design.cart;

interface CartItem {
    public String getName();

    public double getPrice();

    public void setPrice(double price);
}