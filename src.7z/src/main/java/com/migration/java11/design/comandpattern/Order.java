package com.migration.java11.design.comandpattern;

public interface Order {

    void placeOrder();

    void serveOrder();
}
