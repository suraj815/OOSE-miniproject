package com.migration.java11.design.cart;

class Tshirt extends Product {
    public Tshirt(String name, double price) {
        this.name = name;
        this.price = price;
    }
}