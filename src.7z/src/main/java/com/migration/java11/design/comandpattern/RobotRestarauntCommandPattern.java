package com.migration.java11.design.comandpattern;

// Design a solution approach for a restaurant management system where robots
//  are using the software. 
// Their expectation was to design the system which can be leveraged by robots 
// to check available tables, book table, place order, serve order etc.
public class RobotRestarauntCommandPattern {

    public static void main(String[] args) {
        try {

            RobotInvoker robot = new RobotInvoker();

            // checking table availability
            Table1 table1 = new Table1();
            TableAvailableCommand tableAvailableCommand = new TableAvailableCommand(table1);
            BookTableCommand bookTable = new BookTableCommand(table1);

            robot.setCommand(tableAvailableCommand); // command to check the availability of table
            robot.initiate();
            
            robot.setCommand(bookTable); // command to book the table
            robot.initiate();

            // command to order burger
            BurgerOrder burgerOrder = new BurgerOrder();
            PlaceOrderCommand placeBurgerOrder = new PlaceOrderCommand(burgerOrder);
            robot.setCommand(placeBurgerOrder);
            robot.initiate();

            //command to order pasta
            PastaOrder pastaOrder = new PastaOrder();
            PlaceOrderCommand placePastaOrder = new PlaceOrderCommand(pastaOrder);
            robot.setCommand(placePastaOrder);
            robot.initiate();

            //command to serve pasta
            ServeOrderCommand servePastaCommand = new ServeOrderCommand(pastaOrder);
            robot.setCommand(servePastaCommand);
            robot.initiate();

            //comand to serve Burger 
            ServeOrderCommand serveBurgerCommand = new ServeOrderCommand(burgerOrder);
            robot.setCommand(serveBurgerCommand);
            robot.initiate();


        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }
}
