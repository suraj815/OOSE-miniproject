package com.migration.java11.design.comandpattern;

public class TableAvailableCommand implements Command {

    private Table table;

    public TableAvailableCommand(Table table) {
        this.table = table;
    }

    @Override
    public void execute() {
        table.checkAvailability();
    }

}
