package com.migration.java11.design.comandpattern;

public class ServeOrderCommand implements Command {

    Order order;

    public ServeOrderCommand(Order order) {
        this.order = order;
    }

    @Override
    public void execute() {
        this.order.serveOrder();
    }

}
