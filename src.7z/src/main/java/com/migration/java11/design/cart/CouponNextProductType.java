package com.migration.java11.design.cart;

class CouponNextProductType implements Coupon {
    private static final float DISCOUNT = 0.10f;
    private int discountItemStartIndex;
    // private Product productType;
    private Class<?> productType;
    Coupon successor;

    // CouponNextProductType(int discountItemIndex, Product product) {
    // this.discountItemIndex = discountItemIndex;
    // this.productType = product;
    // }

    public CouponNextProductType(int size, Class<? extends CartItem> clazz) {
        this.discountItemStartIndex = size;
        this.productType = clazz;
    }

    public void setSuccessor(Coupon successor) {
        this.successor = successor;
    }

    public void apply(Cart cart) {
        System.out.println("Applying  CouponNextProductType discount on item number :" + discountItemStartIndex);
        if (discountItemStartIndex < cart.getItems().size()) {
            for (int i = discountItemStartIndex; i < cart.getItems().size(); ++i) {
                CartItem cartItem = cart.getItems().get(i);
                System.out.println("Item at index " + i + " is : " + cartItem.getName());
                if (productType.isInstance(cartItem)) {
                    cartItem.setPrice(cartItem.getPrice() - cartItem.getPrice() * DISCOUNT);
                    break;
                }
            }
        }
        if (successor != null) {
            successor.apply(cart);
        }
    }
}
