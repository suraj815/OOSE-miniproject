package com.migration.java11.design.cart;

import java.util.List;

interface Cart {
    List<CartItem> getItems();
    // void setItems(Set cartItems);
}