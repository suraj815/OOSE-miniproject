package com.migration.java11.design.comandpattern;

public class Table1 implements Table{

    @Override
    public void checkAvailability() {
        System.out.println("Table 1 is available");
    }

    @Override
    public void bookTable() {
        System.out.println("Table 1 is booked");
    }

}
