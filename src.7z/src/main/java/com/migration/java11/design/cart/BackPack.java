package com.migration.java11.design.cart;

class BackPack extends Product {
    public BackPack(String name, double price) {
        this.name = name;
        this.price = price;
    }
}