package com.migration.java11.design.comandpattern;

public class BurgerOrder implements Order{

    @Override
    public void placeOrder() {
        System.out.println("Burger order is placed");
    }

    @Override
    public void serveOrder() {
        System.out.println("Your Burger is served");
    }

}
