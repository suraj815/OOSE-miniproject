package com.migration.java11.design.comandpattern;

public class Table2 implements Table{

    @Override
    public void checkAvailability() {
        System.out.println("Table 2 is available");
    }

    @Override
    public void bookTable() {
        System.out.println("Table 2 is booked");
    }

}
