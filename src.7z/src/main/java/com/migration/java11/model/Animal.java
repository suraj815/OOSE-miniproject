package com.migration.java11.model;

import java.io.IOException;

public class Animal {

    private String name;
    Animal(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public void makeSound() throws IOException{
        System.out.println(name + " Animal makes sound");
    }
}

class Dog extends Animal{
    
    Dog(String name){
        super(name);
    }
    public void m() throws ArithmeticException{
        System.out.println("Inside m method");
        // throw new IOException("IO exception from methdo m()");
        throw new ArithmeticException("Arithmetic exception from methdo m()");
    }
    public void makeSound(){
        m();
        //throw new IOException("Throwing Arithmetic Exception");
        // System.out.println(getName() + " Barks!!!");
    }

    public static void main(String[] args) {
        try {
            Animal a = new Dog("Jacky");
            a.makeSound();

            Dog d = (Dog) new Animal("Animalwa");
            d.makeSound();
        } catch (Exception e) {
            // TODO: handle exception
            // StackOverflowError
            System.out.println("Inside Main Catch Block : " + e.getMessage());
            // e.printStackTrace();
        }
    }
}
