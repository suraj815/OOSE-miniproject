package com.migration.java11.model;

import java.util.HashSet;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// @Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Person {

    private String name;
    private String state;
    private String city;


    // @Override
    // public boolean equals(Object obj) {
    //     // if (this == obj)
    //     //     return true;
    //     // if (obj == null)
    //     //     return false;
    //     // if (getClass() != obj.getClass())
    //     //     return false;
    //     // Person other = (Person) obj;
    //     // if (name == null) {
    //     //     if (other.name != null)
    //     //         return false;
    //     // } else if (!name.equals(other.name))
    //     //     return false;
    //     // if (state == null) {
    //     //     if (other.state != null)
    //     //         return false;
    //     // } else if (!state.equals(other.state))
    //     //     return false;
    //     // if (city == null) {
    //     //     if (other.city != null)
    //     //         return false;
    //     // } else if (!city.equals(other.city))
    //     //     return false;
    //     return true;
    // }
    // @Override
    // public int hashCode() {
    //     final int prime = 31;
    //     int result = 1;
    //     // result = prime * result + ((name == null) ? 0 : name.hashCode());
    //     // result = prime * result + ((state == null) ? 0 : state.hashCode());
    //     result = prime * result + ((city == null) ? 0 : city.hashCode());
    //     return result;
    // }


    public static void main(String[] args) {
        try {
            Set<Person> set = new HashSet<>();
            Person p1 = new Person("suraj", "maharashtra", "mumbai");
            Person p2 = new Person("suraj", "maharashtra", "mumbai");
            System.out.println(set.add(p1));
            System.out.println(set.add(p2));
            System.out.println(set.size());
        } catch (Exception e) {
            // TODO: handle exception
        }
    }
    
}
