package com.migration.java11.thread;

import java.util.concurrent.Semaphore;

public class SemaphoreExample {

    private static final int MAX_CONNECTIONS = 5;
    private final Semaphore semaphore = new Semaphore(MAX_CONNECTIONS, true);
    
    public void connect() {
        try {
            semaphore.acquire();
            System.out.println(Thread.currentThread().getName() + " has acquired a database connection");
            
            Thread.sleep((long) (Math.random()*1000));

            System.out.println(Thread.currentThread().getName() + " has released a database connection");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }finally{
            // System.out.println("waiting...");
            semaphore.release();
        }
    }


    public static void main(String[] args) {
        try {
            SemaphoreExample connectionPool = new SemaphoreExample();
            for(int i = 0; i< 10; i++){
                new Thread(connectionPool::connect).start();
            }
            // System.out.println("waiting ... ");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
