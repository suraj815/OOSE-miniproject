package com.migration.java11.thread;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierExample {

    static class Biker implements Runnable {

        String name;
        CyclicBarrier barrier;
        int travelTime;

        public Biker(String name, CyclicBarrier cyclicBarrier, int travelTime) {
            this.name = name;
            this.barrier = cyclicBarrier;
            this.travelTime = travelTime;
        }

        @Override
        public void run() {
            System.out.println(name + " started the journey");
            
            try {
                Thread.sleep(travelTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(name + " reached the common point and waiting for others");

            try {
                barrier.await();
            } catch (InterruptedException | BrokenBarrierException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        
    }


    public static void main(String[] args) {
        try {
            CyclicBarrier barrier = new CyclicBarrier(3, () -> {System.out.println("All Bikers reached common point!");});

            Thread t1 = new Thread(new Biker("Biker 1", barrier, 1000));
            Thread t2 = new Thread(new Biker("Biker 2", barrier, 2000));
            Thread t3 = new Thread(new Biker("Biker 3", barrier, 3000));
            // Thread t4 = new Thread(new Biker("Biker 4", barrier, 4000));

            t3.start();
            t2.start();
            t1.start();
            // t4.setDaemon(true);
            // t4.start();

            // Thread.sleep(10000);
            // t4.interrupt();

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }
}
