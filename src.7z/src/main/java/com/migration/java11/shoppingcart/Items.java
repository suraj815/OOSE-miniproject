package com.migration.java11.shoppingcart;

public interface Items {

}
