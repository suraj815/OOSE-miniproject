package com.migration.java11.shoppingcart;

public class Product implements Items{

    private Double price;
    private String type;

}
