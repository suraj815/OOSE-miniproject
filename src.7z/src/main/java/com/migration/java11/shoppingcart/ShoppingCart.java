package com.migration.java11.shoppingcart;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

    public static void main(String[] args) {
        List<Items> items = new ArrayList<>();
        checkout(items);
    }

    private static void checkout(List<Items> items) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'checkout'");
    }
}
