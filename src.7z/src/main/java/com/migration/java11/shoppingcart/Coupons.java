package com.migration.java11.shoppingcart;

public class Coupons implements Items{

    // private 
}
