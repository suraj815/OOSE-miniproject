package com.migration.java11.optional;

import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Stream;

public class OptionalDemo {

    static String getOutput(String input) {
        return input == null ? null : "output for " + input;
    }

    static Optional<String> getOutputOpt(String input) {
        return input == null ? Optional.empty() : Optional.of("output for " + input);
    }

    public static void main(String[] args) {
        try {

            // Stream<String> streamString = Stream
            // Object

            // Arrays.asList(null);

            Optional<String> s = Optional.of("input");
            System.out.println(s.map(OptionalDemo::getOutput));
            System.out.println(s.flatMap(OptionalDemo::getOutputOpt));

            Optional<String> checkExist = Optional.ofNullable("null nahi hu");
            checkExist = Optional.empty();
            // System.out.println(checkExist.get());
            // String a = checkExist.orElse(null);
            // System.out.println(a);
            checkExist.ifPresent(System.out::println);
            System.out.println(checkExist.filter((a) -> "null nahi hu".equals(a)).orElse("null hai re"));

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }
}
