package com.migration.java11.ioenhancements;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class IOEnhancementsDemo {

    public static void main(String[] args) {
        try {
            // Stream
            // Arrays.parallelSort()
            List<Path> paths = Files.list(Paths.get("C:\\Users\\SurajY3\\Learning\\java11SpringBoot")).collect(Collectors.toList());
            paths.forEach(System.out::println);
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();;
        }
    }
}
