package com.migration.java11.controller;

import com.migration.java11.config.kafka.JsonKafkaProducer;
import com.migration.java11.entity.Employee;
import com.migration.java11.services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/employee")
public class EmployeeController {

    EmployeeService employeeService;

    private JsonKafkaProducer jsonKafkaProducer;

    public EmployeeController(EmployeeService employeeService, JsonKafkaProducer jsonKafkaProducer) {
        this.employeeService = employeeService;
        this.jsonKafkaProducer = jsonKafkaProducer;
    }

    @GetMapping()
    public List<Employee> getEmployee(){
        return employeeService.getEmployee();
    }

    @PostMapping()
    public List<Employee> getEmployee(@RequestBody List<Employee> employees){
        return employeeService.saveEmployee(employees);
    }

    @PostMapping("/publish")
    public String publishEmployee(@RequestBody Employee employee){
        jsonKafkaProducer.sendMessage(employee);
        return "Message published";
    }
}
