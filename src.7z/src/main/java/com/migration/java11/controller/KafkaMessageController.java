package com.migration.java11.controller;


import com.migration.java11.config.kafka.KafkaProducer;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/kafka")
public class KafkaMessageController {

    private KafkaProducer kafkaProducer;

    public KafkaMessageController(KafkaProducer kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    //http://localhost:8080/api/v1/kafka/publish?message=hello world
    @GetMapping("/publish/")
    public String sendMessage(@RequestParam("message") String message){
        kafkaProducer.sendMessage(message);
        return "Message published succesfully";
    }

}
