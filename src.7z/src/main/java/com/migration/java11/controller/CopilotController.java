package com.migration.java11.controller;

import java.sql.Date;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Stream;

public class CopilotController {
    private int calculateDaysBetweenDatesAnInt(Date d) {
        System.out.println(d);
        int abc = 0;
        return abc;

    }

    public static void main(String[] args) {

        try {

            Map<String, String> map = new HashMap<>();
            ArrayBlockingQueue<String> arrayBlockingQueue = new ArrayBlockingQueue<>(2);
            arrayBlockingQueue.add("one");
            arrayBlockingQueue.add("two");
            System.out.println(arrayBlockingQueue.add("three"));
            
            System.out.println("Inside Try");
        } catch (Exception e) {
            e.printStackTrace();
        }
        

        HashMap<String, String> map = new HashMap<String, String>();
        map.put("key1", "Java");
        map.put("key2", "Servlets");
        map.put("key3", "JSP");
        map.put("key1", "C#");
        System.out.println(map);

    }

}

abstract class A {
    int i;

    abstract void display();
}

class B extends A {
    int j;

    void display() {
        System.out.println(j);
    }
}

class Abstract_demo {
    public static void main(String args[]) {
        B obj = new B();
        obj.j = 2;
        obj.display();

        String a = "ABCD";

        a.concat("DEF");
        System.out.println(a);
    }
}

class Bitset {
    public static void main(String args[]) {
        BitSet obj = new BitSet(5);
        for (int i = 0; i < 5; ++i)
            obj.set(i);
        obj.clear(2);
        System.out.print(obj);
    }
}
