package com.migration.java11.services;

import com.migration.java11.entity.Employee;
import com.migration.java11.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import javax.transaction.Transactional;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;
    List<Employee> empList = List.of(new Employee("1", "Suraj", "yadav", 28, "surajy145@gmail.com"),
            new Employee("2", "Sachin", "yadav", 26, "sachin@gmail.com"),
            new Employee("3", "Satish", "yadav", 30, "satish@gmail.com"),
            new Employee("4", "Shivam", "yadav", 20, "shivam@gmail.com"));
    public List<Employee> getEmployee() {
        return employeeRepository.findAll();
    }

    @Transactional
    public List<Employee> saveEmployee(List<Employee> employees) {
        return employeeRepository.saveAll(employees);
    }
}
