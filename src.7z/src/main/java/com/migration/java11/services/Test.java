package com.migration.java11.services;

import java.util.Date;

public class Test {

    public static void main(String[] args) {

        System.out.println("Inside main");
    }
    private int calculateDaysBetweenDates(Date date1, Date d2){
        return 0;
    }

}
