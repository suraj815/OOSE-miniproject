package com.migration.java11;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.migration.java11.model.Person;

// @SpringBootApplication
public class Java11Application {

	public static void main(String[] args) {

		String a = "hello";
		String b = "hello";

		String c = new String("hello");
		System.out.println(a == b);
		System.out.println(b == c);
		System.out.println(b.equals(c));

		Thread t1 = new Thread( () -> System.out.println("created thread "));
		String d = a.intern();
		t1.start();

		Map<Integer, Object> map = new HashMap<>();
		System.out.println(map.put(1, "Suraj"));
		System.out.println(map.put(1, "Sachin"));

		List<Person> list = new ArrayList<>();
		list.add(new Person("suraj", "maharashtra", "thane"));
		list.add(new Person("sachin", "maharashtra", "ulhasnagar"));
		list.add(new Person("shivam", "maharashtra", "thane"));
		list.add(new Person("kajal", "maharashtra", "ulhasnagar"));
		list.add(new Person("satish", "uttarpradesh", "jaunpur"));
		list.add(new Person("siyaram", "uttarpradesh", "jaunpur"));
		list.add(new Person("arpana", "madhyapradesh", "jabalpur"));
		list.add(new Person("hemant", "madhyapradesh", "satna"));
		list.add(new Person("satish", "maharashtra", "mumbai"));

		List<Integer> intList = new ArrayList<>();
		intList.add(1);intList.add(2);intList.add(3);intList.add(4);intList.add(5);

		System.out.println(intList.stream().mapToInt(e -> e*2).sum());
		//Stream
		System.out.println(list.stream().allMatch(e -> e.equals("kajal")));
		System.out.println(list.stream().anyMatch(e -> e.equals("kajal")));

		Map<String, List<String>> personByState = list.stream()
													.collect(Collectors.groupingBy(
																		Person::getState, 
																		Collectors.mapping(Person::getName, Collectors.toList())));
		System.out.println(personByState);
		//SpringApplication.run(Java11Application.class, args);
	}

}
