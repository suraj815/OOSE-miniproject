package com.migration.java11.config.kafka;

import com.migration.java11.entity.Employee;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.stereotype.Service;

@Service
public class JsonKafkaConsumer {

    private static final Logger LOGGER = LoggerFactory.getLogger(JsonKafkaConsumer.class);
    @KafkaListener(topics = "jsonguides", groupId = "myGroup")
    public void consume(Employee employee){
        LOGGER.info("Inside JSON KAFKA CONSUMER: consumed data : {}", employee);
    }
}
