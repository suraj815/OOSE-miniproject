package com.migration.java11.stream;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamLearning {

    public static void main(String[] args) {
        try {

            // Print duplicate characters in a string?

            String inputString = "Java Concept Of The Day".replaceAll("\\s+", "").toLowerCase();
            Set<String> uniqueChars = new HashSet<>();
            Set<String> duplicateChars = Arrays.stream(inputString.split(""))
                    .filter(ch -> !uniqueChars.add(ch))
                    .collect(Collectors.toSet());

            List<Integer> myList = Arrays.asList(10, 15, 8, 49, 25, 98, 98, 32, 15);

            Integer max = myList.stream().max(Integer::compare).get();
            System.out.println(max);

            // How to count each element/word from the String ArrayList in Java8?
            List<String> names = Arrays.asList("AA", "BB", "AA", "CC");
            Map<String, Long> namesCount = names.stream()
                    .collect(Collectors.groupingBy(Function.identity(),
                            Collectors.counting()));

            System.out.println(namesCount);

            // How do you find frequency of each character in a string using Java 8
            // streams??

            String inputString1 = "Java Concept Of The Day";
            Map<Character, Long> map = inputString1.chars().mapToObj(c -> (char) c)
                    .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));
            System.out.println(map);

            // How do you find frequency of each element in an array or a list?
            List<String> stationeryList = Arrays.asList("Pen", "Eraser", "Note Book", "Pen", "Pencil", "Stapler",
                    "Note Book", "Pencil");
            // Map<String, Long> stationaryCountMap =
            // stationeryList.stream().collect(Collectors.groupingBy(Function.identity(),
            // Collectors.counting()));
            // if order needs to be maintained then
            Map<String, Long> stationaryCountMap = stationeryList.stream()
                    .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));
            System.out.println(stationaryCountMap);

            // How do you get three maximum numbers and three minimum numbers from the given
            // list of integers?

            List<Integer> listOfIntegers = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);
            listOfIntegers.stream().sorted().limit(3).forEach(System.out::println); // min
            listOfIntegers.stream().sorted(Collections.reverseOrder()).limit(3).forEach(System.out::println); // max

            checkAnagram("carRace", "raceCar");

            // Find second largest number in an integer array

            List<Integer> listOfIntegersss = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89, 89);
            Integer secondLargest = listOfIntegersss.stream().distinct().sorted(Collections.reverseOrder()).skip(1)
                    .findFirst().get();
            System.out.println(secondLargest);

            // Given a list of strings, sort them according to increasing order of their
            // length?

            List<String> listOfStrings = Arrays.asList("Java", "Python", "C#", "HTML", "Kotlin", "C++", "COBOL", "C");
            List<String> sortedListLengthWise = listOfStrings.stream().sorted(Comparator.comparing(String::length))
                    .collect(Collectors.toList());
            System.out.println(sortedListLengthWise);

            reverseEarchWordInString();
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }

    private static void reverseEarchWordInString() {
        // Reverse each word of String using java 8 streams?
        String str = "Java Concept Of The Day";
        String revreString = Arrays.stream(str.split(" "))
                .map(e -> new StringBuffer(e).reverse())
                .collect(Collectors.joining(" "));

        // List<String> reverseList = Arrays.stream(str.split(" ")).sorted(Collections.reverseOrder())
        //         .collect(Collectors.toList());
        // System.out.println(reverseList);
        System.out.println(revreString);
    }

    private static void checkAnagram(String s1, String s2) {
        String a = Stream.of(s1.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
        String b = Stream.of(s2.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());

        if (a.equals(b))
            System.out.println("anagram");
        else
            System.out.println("Not an ANagram");
    }
}
